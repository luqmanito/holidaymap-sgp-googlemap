# built using Next.js


# cd google-maps-intro
# npm i
# npm run dev

it will runningon your localhost